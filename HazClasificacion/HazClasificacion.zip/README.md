## HazClasificacion

test: Survived_binarizes
Este test se aplica sobre un conteo binarizado a la lista de supervivientes.
 
classifier: rulesJR
Escogí este clasificador porque dio muy buenos resultados una vez hecho el proceso de binarización.